import React from "react";

const ProjectProcess = () => {
  return <div>ProjectProcess</div>;
};

export default ProjectProcess;
