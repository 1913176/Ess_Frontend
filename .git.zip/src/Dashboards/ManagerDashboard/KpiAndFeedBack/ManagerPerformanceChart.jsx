import React from "react";

const ManagerPerformanceChart = ({ setischart }) => {
  return (
    <div>
      <p className="p-2">Chart</p>
      {/* <p onClick={() => setischart((pre) => !pre)} className='border border-gray-300 rounded-md bg-blue-400 w-[80px] px-2 py-1 text-center ms-2 '>Close</p> */}
    </div>
  );
};

export default ManagerPerformanceChart;
