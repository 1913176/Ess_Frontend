import axios from "axios";
import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
const apiBaseUrl = process.env.VITE_BASE_API;
const UpdateGoal = ({
  setUpdateGoalPopup,
  goalId,
  ManagerList,
  fetchGoalList,
}) => {
  const [GoalData, setGoalData] = useState({
    manager: "",
    goal_text: "",
    start_date: "",
    end_date: "",
    is_completed: false,
  });

  useEffect(() => {
    const fetchGoalData = async () => {
      if (!goalId) {
        console.error("Goal ID is undefined");
        toast.error("Goal ID is missing. Please try again.");
        return;
      }
      try {
        const { data } = await axios.get(
          `${apiBaseUrl}/goals-manager/${goalId}/`,
        );
        setGoalData({
          id: data.id,
          manager: data.manager.manager_name,
          goal_text: data.goal_text,
          start_date: data.start_date,
          end_date: data.end_date,
          is_completed: data.is_completed,
        });
      } catch (error) {
        console.error("Error fetching goal data:", error);
        toast.error("Failed to fetch goal data.");
      }
    };

    fetchGoalData();
  }, [goalId]);

  const handleUpdateGoal = async (e) => {
    e.preventDefault();

    try {
      // Format dates to 'YYYY-MM-DD' and ensure `is_completed` is boolean
      const formattedData = {
        ...GoalData,
        start_date: new Date(GoalData.start_date).toISOString().split("T")[0],
        end_date: new Date(GoalData.end_date).toISOString().split("T")[0],
        is_completed: GoalData.is_completed === true, // Ensure boolean value
      };

      // Send data as JSON instead of FormData
      const { data } = await axios.put(
        `${apiBaseUrl}/admin/update-manager-goal/${goalId}/`,
        formattedData, // JSON payload
        {
          headers: { "Content-Type": "application/json" },
        },
      );

      toast.success("Goal updated successfully.");
      fetchGoalList(); // Refresh the list
      setUpdateGoalPopup(false);
    } catch (error) {
      console.error("Error updating Goal:", error);
      toast.error(
        error.response?.data?.errors
          ? Object.values(error.response.data.errors).flat().join(", ")
          : "Failed to update Goal.",
      );
    }
  };

  return (
    <>
      <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 items-center justify-center z-50">
        <div className="bg-white rounded-lg p-8 w-full max-w-2xl mx-4 shadow-xl">
          <h1 className="text-2xl font-semibold mb-6">Update Manager Goal</h1>
          <form className="space-y-6 w-full" onSubmit={handleUpdateGoal}>
            <div className="grid gap-6 w-full">
              <div className="space-y-4">
                <h2 className="font-medium text-gray-700">Goal Details</h2>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 items-center gap-2 w-full">
                    <label className="text-sm font-medium">Manager Name</label>
                    <select
                      id="manager"
                      className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                      value={GoalData.manager}
                      onChange={(e) =>
                        setGoalData({
                          ...GoalData,
                          manager: e.target.value,
                        })
                      }
                    >
                      <option value="" disabled>
                        Select Manager
                      </option>
                      {ManagerList.map((manager) => (
                        <option key={manager.manager_id} value={manager.id}>
                          {manager.manager_name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-3 items-center gap-2 w-full">
                    <label className="text-sm font-medium">Goal Text</label>
                    <input
                      type="text"
                      placeholder="Enter description"
                      className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                      value={GoalData.goal_text}
                      onChange={(e) =>
                        setGoalData({
                          ...GoalData,
                          goal_text: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div className="grid grid-cols-3 items-center gap-2 w-ful">
                    <label className="text-sm font-medium">Start Date</label>
                    <input
                      type="date"
                      className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                      value={GoalData.start_date}
                      onChange={(e) =>
                        setGoalData({
                          ...GoalData,
                          start_date: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div className="grid grid-cols-3 items-center gap-2 w-ful">
                    <label className="text-sm font-medium">End Date</label>
                    <input
                      type="date"
                      className="w-full px-3 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 col-span-2"
                      value={GoalData.end_date}
                      onChange={(e) =>
                        setGoalData({
                          ...GoalData,
                          end_date: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div className="grid grid-cols-3 items-center gap-2 w-full">
                    <label
                      htmlFor="is_completed"
                      className="text-sm font-medium"
                    >
                      Is Completed
                    </label>
                    <div className="col-span-2 flex items-center gap-4">
                      <input
                        type="checkbox"
                        id="is_completed"
                        className="hidden"
                        checked={GoalData.is_completed}
                        onChange={(e) =>
                          setGoalData({
                            ...GoalData,
                            is_completed: e.target.checked, // Boolean value
                          })
                        }
                      />
                      <button
                        type="button"
                        className={`px-4 py-2 text-sm font-medium rounded-lg ${
                          GoalData.is_completed
                            ? "bg-green-500 text-white"
                            : "bg-red-500 text-white"
                        }`}
                        onClick={() =>
                          setGoalData({
                            ...GoalData,
                            is_completed: !GoalData.is_completed,
                          })
                        }
                      >
                        {GoalData.is_completed ? "Yes" : "No"}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-4 mt-8">
              <button
                type="button"
                onClick={() => setUpdateGoalPopup(false)}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-gray-400"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default UpdateGoal;
